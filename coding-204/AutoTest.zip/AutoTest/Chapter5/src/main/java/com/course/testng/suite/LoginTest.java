package com.course.testng.suite;

import org.testng.annotations.Test;

public class LoginTest {

    @Test
    public void loginTaoBao(){
        System.out.println("淘宝登陆成功");
    }
}
