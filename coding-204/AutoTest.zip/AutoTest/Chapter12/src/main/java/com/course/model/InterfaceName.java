package com.course.model;

public enum InterfaceName {
    GETUSERLIST,LOGIN,UPDATEUSERINFO,GETUSERINFO,ADDUSERINFO
}
